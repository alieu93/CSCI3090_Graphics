/*
	UOIT CSCI 3090 Assignment 4 Bonus Question, Christopher Collins
	Modified source code from Daniel Vogel

	Portions may be adapted from:

	1) Suplemental code provided by Interactive Computer Graphics
	A Top-Down Approach with OpenGL, Edward Angel and Dave Shreiner
	Sixth Edition, Addison-Wesley 2012
	http://www.cs.unm.edu/~angel/BOOK/INTERACTIVE_COMPUTER_GRAPHICS/SIXTH_EDITION/CODE/

	2) From code supplied by http://openglbook.com/

	Copyright (C) 2011 by Eddy Luten

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the "Software"), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A DEMOICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
	THE SOFTWARE.

*/

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#include <stdlib.h>

#include <iostream>
#include <sstream>
#include <string>

// stl variable array is called a vector
#include <vector>

// includes OpenGl libraries in a cross-platform way
#include "gl_include.h"

// include the helper files
#include "gl_utilities.h"

// include useful types for vectors and matrices
#include "vec.h"
#include "mat.h"

#include "arcBall.h"

djv::Arcball arcballModel;
djv::Arcball arcballLight;
djv::Arcball* arcball;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// set-up some adjustable variables for
// interactive demonstrations
#include "Adjustable.h"

djv::Adjustable adjustable;

GLfloat X = 0; // translation
GLfloat Y = 0;
GLfloat Z = 0;

GLfloat U = 1; // scale
GLfloat V = 1;
GLfloat W = 1;

// adjust texture mapping location
GLfloat A = 0;  // smin
GLfloat B = 1;	// smax
GLfloat C = 0;	// tmin
GLfloat D = 1;	// tmax


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// use the djv namespace (avoid djv:: prefixes)
using namespace djv;

using std::cout;
using std::endl;

// for loading texture map images
#include "stb_image.h"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

GLuint program; // the OpenGL program "name"

// uniform variable 'name' ids 
GLint uniformId_projection;
GLint uniformId_modelView;
GLint uniformId_textureSampler;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// initialize the vertex and fragment shaders
void initShaders(void)
{
	std::cout << "initializing shaders" << std::endl;

	program = loadAndInitializeShaders( "textmap-vshader.glsl", "textmap-fshader.glsl" );
	
	// get location id for uniform variables in shader program
	uniformId_modelView = glGetUniformLocationHelper(program, "modelView");
	uniformId_projection= glGetUniformLocationHelper(program, "projection");

	// id of texture sampler uniform
	uniformId_textureSampler = glGetUniformLocationHelper(program, "texture");


	//CHECK_GL_ERROR;

	glUseProgram( program );
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


struct Vertex
{
	Vertex(vec3 pos, vec2 tex) { position = pos; texture = tex; };
	vec3 position;
	vec2 texture;
};


// usual buffer variables
GLuint bufferId_vertices;
GLuint bufferId_indices;
int drawNum;
size_t vertexStride; 
size_t textCoordOffset; 
GLint attributeId_vPosition;
GLint attributeId_vTextCoord;

void initSimpleTexMesh()
{
	// create a mesh 
	std::vector<Vertex> vertices;

	int W = 5;
	int H = 5;

	vec3 offset((float)(W - 1)/2.0f, (float)(H - 1)/2.0f, 0.0f);

	for (int x = 0; x < W; x++)
		for (int y = 0; y < H; y++)
		{
			vec3 position(x, y, 0.0f);

			// texture coordinates 
			// A,B are min and max s value (usually 0 and 1)
			float s = A + B * ((float)x / (W - 1));
			// C,D are min and max s value (usually 0 and 1)
			float t = C + D * ((float)y / (H - 1));

			vec2 texureCoord(s, t);
			vertices.push_back(Vertex(position - offset, texureCoord));
		}

	glGenBuffers(1, &bufferId_vertices);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);

	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), 
		&vertices.front(), GL_STATIC_DRAW);

	// need these to tell the shader how attributes are stored
	vertexStride = sizeof(vertices[0]);
	textCoordOffset = sizeof(vertices[0].position);

	// now generate indices 
	std::vector< GLushort > indices;

	// we're going to use TRIANGLES
	for (int x = 0; x < W - 1; x++)
		for (int y = 0; y < H - 1; y++)
		{	
			// triangle 1
			indices.push_back((x * H) + y); 
			indices.push_back(((x + 1) * H ) + y + 1); 
			indices.push_back(((x + 1) * H) + y); 

			// triangle 2
			indices.push_back((x * H) + y); 
			indices.push_back((x * H) + y + 1); 
			indices.push_back(((x + 1) * H) + y + 1); 
		}

	// index buffer
	glGenBuffers(1, &bufferId_indices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), 
		&indices.front(), GL_STATIC_DRAW);

	// the number of triangles to draw
	drawNum = indices.size();

	// find the shader variable locations
	attributeId_vPosition  = glGetAttribLocationHelper(program, "vPosition");
	glEnableVertexAttribArray(attributeId_vPosition);
	attributeId_vTextCoord  = glGetAttribLocationHelper(program, "vTextCoord");
	glEnableVertexAttribArray(attributeId_vTextCoord);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


void initGeometry( void )
{
	std::cout << "initializing geometry" << std::endl;

	// Create a vertex array object
	GLuint vao;
	#ifdef __APPLE__
		glGenVertexArraysAPPLE( 1, &vao );
		glBindVertexArrayAPPLE( vao );
	#else
		// if it crashes here, it could be because VertexArrays aren't supported
		// on your card, but perhaps an extension is available
		glGenVertexArrays( 1, &vao );
		glBindVertexArray( vao );
	#endif

	initSimpleTexMesh();

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// helper function to find next power of two
inline 
int nextPowerOf2(int a)
{
	return (pow(2.0, (int)ceil((float)log((float)a)/(float)log(2.0))));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

const int checkWidth = 64;
const int checkHeight = 64;
static GLubyte checkImage[checkWidth][checkHeight][4];

// the texture "name"
static GLuint texName;

// the max texture coordinates to fill with the texture
// these may not be 1 if a non-power-of-two image is used
// for the image
double texMaxS = 1.0;
double texMaxT = 1.0;


// use mipmapping
bool mipmap = false;


// initialize textures
void initTextures(void)
{
	// load or create a texture image
	unsigned char *image;
	int width;
	int height;
	GLint format;

	bool load = false;
		
	int x,y,n;

	std::string filename = "bricks_color_map.jpg"; 
		
	load = true;

	// ... x = width, y = height, n = # 8-bit components per pixel ...
	// ... replace '0' with '1'..'4' to force that many components per pixel
	// NOTE: some formats like PNG and JPG, the origin is often at top left,
	// not bottom left, so your image may be upside down. You can fix by changing
	// how you map texture coordinates, or flip the raw image data before assigning
	// to a texture
	unsigned char *data = stbi_load(filename.c_str(), &x, &y, &n, 0);
	if (!data)
	{
		cout << "ERROR loading image: " << stbi_failure_reason() << endl;
		// if you get an error with "can't fopen", then your image wasn't found
		// if you're  using a relative path, make sure you know where the working
		// directory is. For example, with Eclipse/CDT, the working directory is the root
		// project directory
	}
	else
	{
		cout << "Loaded '" << filename << "' (" << x << " x " << y << ", " << n << " bytes per pixel)" << endl;
			switch(n)
		{
		case 1:
			format = GL_LUMINANCE;
			break;
			case 2:
			format = GL_LUMINANCE_ALPHA;
			break;
			case 3:
			format = GL_RGB;
			break;
			case 4:
			format = GL_RGBA;
			break;
			// shouldn't happen
		default:
			cout << "ERROR parsing image: unsupported pixel depth" << endl;
			break;
		}
		image = data;
	}
	width = x;
	height = y;
	image = data;

	int maxSize;
	glGetIntegerv(GL_MAX_TEXTURE_SIZE, &maxSize);

	if (width > 2 + maxSize || height > 2 + maxSize)
	{
		cout << "ERROR creating texture: max width and height is " << maxSize << endl;
	}

	// texture settings

	// use tightly packed data
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

	// need to generate a texture "name" similar to display lists
   glGenTextures(1, &texName);

   // bind the texture (and set it's "type", usually a 2D texture)
   glBindTexture(GL_TEXTURE_2D, texName);


   // need to be careful about images which have a width or
   // height which is non-power-of-two
   int widthP2 = nextPowerOf2(width);
   int heightP2 = nextPowerOf2(height);

   if (widthP2 != width || heightP2 != height)
   {
	   cout << "WARNING non-power-of-two image size, padding to " << widthP2 << ", " << heightP2 << endl;

	   // first, create a NULL texture with power of two dimensions
	   glTexImage2D(GL_TEXTURE_2D, 0, format, widthP2, heightP2,
				    0, format, GL_UNSIGNED_BYTE, NULL);

		// then, place the (possibly not power of 2) image
	   //  into the NULL texture
	   glTexSubImage2D(GL_TEXTURE_2D, 0, 0,0, width, height,
				    format, GL_UNSIGNED_BYTE, image);

	   texMaxS = (double)width/widthP2;
	   texMaxT = (double)height/heightP2;
   }
   else
   {
	   glTexImage2D(GL_TEXTURE_2D, 0, format, width, height,
				    0, format, GL_UNSIGNED_BYTE, image);

	   texMaxS = 1.0;
	   texMaxT = 1.0;
   }


    glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
	glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );

	if (mipmap)
		glGenerateMipmap(GL_TEXTURE_2D);

   // adjustable variables for texture mapping
   A = 0.0;
   B = texMaxS;
   C = 0.0;
   D = texMaxT;

   if (load)
	stbi_image_free(image);
}


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// dolly camera in and out
float dolly = 10;

// for adjusting projection matrix on resize
float aspectRatio = 1.0;



int wrapMode = 0;


void display( void )
{
	 // clear the window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// the 'projection' matrix 
	mat4 Projection  = Perspective(30, aspectRatio, 1, 50);
	glUniformMatrix4fv(uniformId_projection, 1, GL_TRUE, Projection);

	// simple fixed camera that can dolly in and out 
	vec4 dir = vec4(0,0,0,1) + normalize(vec4(1,1,1,0)) * dolly;
	mat4 View = LookAt(dir, vec4(0,0,0,1), vec4(0,1,0,0));

	// send the model view matrix
	mat4 ModelView = View;

	// arcball rotate
	ModelView *= transpose(arcballModel.rot);
	ModelView *= Scale(U,V,W);
	
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, ModelView);


	// bind the texture
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, texName); 


	if (wrapMode == 0)
	{
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT );
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT );
	}
	else if (wrapMode == 1)
	{
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE );
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE );
	}
	else if (wrapMode == 2)
	{
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_MIRRORED_REPEAT );
		glTexParameterf( GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_MIRRORED_REPEAT );
	}

	// set the sampler texture to active texture '0' (GL_TEXTURE0)
	glUniform1i(uniformId_textureSampler, 0);

	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);

	// map the buffer data to attribute locations
	glVertexAttribPointer(attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(0));
	glVertexAttribPointer(attributeId_vTextCoord, 2, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(textCoordOffset));

	// draw the mesh
	glDrawElements(GL_TRIANGLES, drawNum, GL_UNSIGNED_SHORT, NULL);

	//CHECK_GL_ERROR;

	// swap buffers and display
	glutSwapBuffers();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// current window width and height
int winHeight;
int winWidth;

void reshape(int width, int height)
{
	std::cout << "reshape " << width << " by " << height << std::endl;

	winWidth = width;
	winHeight = height;

	// update the aspect ratio for the Projection matrix
	aspectRatio = width / (float)height;

	// update the viewport to fit the entire area
	glViewport(0, 0, width, height);

	arcballLight.set_params(vec2(width / 2, height / 2), std::min(width,height) / 2 ); 
	arcballModel.set_params(vec2(width / 2, height / 2), std::min(width,height) / 3 ); 
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// amt to dolly camera in and out
float DOLLY_BY = 1.0;

void keyboard( unsigned char key, int x, int y )
{
	switch ( key )
	{
		// Esc key
		case 033:
			exit( EXIT_SUCCESS );
			break;

		case '_':
			// get current polygon fill mode
			GLint params[2];
			glGetIntegerv(GL_POLYGON_MODE, params);
			// toggle the mode
			if (params[1] == GL_FILL)
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			else
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			break;

		// dolly camera
		case '-':
			dolly += DOLLY_BY;
			break;

		case '+':
			dolly = std::max(1.0f, dolly - DOLLY_BY);
			break;

		case 'f':
			if (glIsEnabled(GL_CULL_FACE))
				glDisable(GL_CULL_FACE);
			else
				glEnable(GL_CULL_FACE);
			break;

		case 'm':
			mipmap = !mipmap;
			initTextures();
			break;

		case 'w':
			wrapMode = (wrapMode + 1) % 3;
			break;

		// toggle light or model rotation with arcball
		case ' ':
			if (arcball == &arcballModel)
				arcball = &arcballLight;
			else
				arcball = &arcballModel;
	}

	adjustable.key(key, x, y);
	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// non ASCII keyboard event callback
void specialKeyboard(int key, int x, int y)
{
	std::string result = adjustable.specialKey(key, x, y);

	// re-init the mesh assuming A,B,C,D were changed
	initSimpleTexMesh();

	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void mouse(int button, int state, int x, int y)
{
	if (state == GLUT_DOWN)
	{
		arcball->mouse_down(x, winHeight - y);
	}
	else if (state == GLUT_UP)
	{
		arcball->mouse_up();
	}
	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void mouseDrag(int x, int y)
{
	int mod = glutGetModifiers();

	arcball->mouse_motion(x, winHeight - y, 
		mod == GLUT_ACTIVE_SHIFT, mod == GLUT_ACTIVE_CTRL, mod == GLUT_ACTIVE_ALT);
	glutPostRedisplay();

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// application entry point
int	main( int argc, char **argv )
{
	// initialize glut
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA );
	glutInitWindowSize( 512, 512 );

	#ifndef __APPLE__
	// If you are using freeglut extensions, ask for an OpenGL
	// version context
    glutInitContextVersion( 2, 1 );
	// this seems to force the most recent version, but would be nice
	// to call since it forces modern OpenGL calls
	//glutInitContextFlags (GLUT_FORWARD_COMPATIBLE );
    //glutInitContextProfile( GLUT_CORE_PROFILE );
	#endif
	// create the window
	glutCreateWindow( "Demo" );

	#ifndef __APPLE__
	// initialize the OpenGL extension wrangler
	glewExperimental = GL_TRUE; // seems to help with older contexts
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		std::cerr << "GLEW Error: " << glewGetErrorString(err) << std::endl;
		return 1;
	}
	#endif

	// query for version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	// set window background colour
	glClearColor( 0.4, 0.4, 0.4, 1.0 );

	// enable depth testing
	glEnable(GL_DEPTH_TEST);

	// blending and smoothing
	glEnable(GL_BLEND); 
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint( GL_LINE_SMOOTH_HINT, GL_NICEST );
	glHint( GL_POLYGON_SMOOTH_HINT, GL_NICEST );

	// load shaders into the GPU
	initShaders();

	// create geometry and put it into the GPU
	initGeometry();

	// initialize textures
	initTextures();

	// set event callback functions
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( keyboard );
	glutSpecialFunc( specialKeyboard );

	glutMouseFunc(mouse);
	glutMotionFunc(mouseDrag);

	// link adjustable parameters
	adjustable.add(&X, 'x', "X");
	adjustable.add(&Y, 'y', "Y");	
	adjustable.add(&Y, 'y', "Y");	

	adjustable.add(&U, 'u', "U");	
	adjustable.add(&V, 'v', "V");	
	adjustable.add(&W, 'w', "W");	

	adjustable.add(&A, 'a', "s_min");	
	adjustable.add(&B, 'b', "s_max");	
	adjustable.add(&C, 'c', "t)min");	
	adjustable.add(&D, 'd', "t_max");	

	arcball = &arcballModel;

	std::cout << "initializing done" << std::endl;

	// enter the main loop
	glutMainLoop();

	// should never get to this point
	return 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
