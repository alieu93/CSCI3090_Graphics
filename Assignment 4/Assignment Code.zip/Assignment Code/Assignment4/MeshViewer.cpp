/*
	COMP 3831 Demos 12
	Daniel Vogel

	Portions may be adapted from:

	1) Suplemental code provided by Interactive Computer Graphics
	A Top-Down Approach with OpenGL, Edward Angel and Dave Shreiner
	Sixth Edition, Addison-Wesley 2012
	http://www.cs.unm.edu/~angel/BOOK/INTERACTIVE_COMPUTER_GRAPHICS/SIXTH_EDITION/CODE/

	2) From code supplied by http://openglbook.com/

	Copyright (C) 2011 by Eddy Luten

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the "Software"), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A DEMOICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
	THE SOFTWARE.

*/

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

/*
	Demo Selection
	--------------
	Use the preprocessor define below to switch between
	different demos. If your editor supports outlining or
	can hide "inactive" code, it will make it easier to
	view individual demo code.

	DEMO 1: lighting with normals using LitMesh, and light and material classes, and arcball

*/
#define DEMO 1


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#include <stdlib.h>

#include <iostream>
#include <sstream>
#include <string>

// stl variable array is called a vector
#include <vector>
#include <stack>
#include <map>



// includes OpenGl libraries in a cross-platform way
#include "gl_include.h"

// include the helper files
#include "gl_utilities.h"

// light and material helper classes
#include "lighting.h"

// include useful types for vectors and matrices
#include "vec.h"
#include "mat.h"

#include "arcBall.h"

djv::Arcball arcballModel;
djv::Arcball arcballLight;
djv::Arcball* arcball;


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// set-up some adjustable variables for
// interactive demonstrations
#include "Adjustable.h"

djv::Adjustable adjustable;

GLfloat X = 0; // translation
GLfloat Y = 0;
GLfloat Z = 0;

GLfloat U = 1; // scale
GLfloat V = 1;
GLfloat W = 1;


// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// use the djv namespace (avoid djv:: prefixes)
using namespace djv;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

GLuint program; // the OpenGL program "name"

// uniform variable 'name' ids 
GLint uniformId_projection;
GLint uniformId_modelView;
GLint uniformId_normalMatrix;


// use the new litmesh geometry (meshes with normals)
#include "litmeshes.h"
LitCubeMesh cube;
int sphereSubdivisions = 4;
LitSphereMesh sphere;
LitCylinderMesh cylinder;
LitTeapotMesh teapot;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// initialize the vertex and fragment shaders
void initShaders(void)
{
	std::cout << "initializing shaders" << std::endl;

	program = loadAndInitializeShaders( "vshader.glsl", "fshader.glsl" );

	// get location id for uniform variables in shader program
	uniformId_modelView = glGetUniformLocationHelper(program, "modelView");
	uniformId_projection= glGetUniformLocationHelper(program, "projection");
	uniformId_normalMatrix= glGetUniformLocationHelper(program, "normalMatrix");
	
	// initialize material and light shader attribute locations
	// (static variables, so one call per class is all that is needed)
	Material::initUniformLocations(program);
	Light::initUniformLocations(program);
	
	//CHECK_GL_ERROR;

	glUseProgram( program );
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

Light light;
Material visualizeNormalsMaterial;

int lightType = 1;

void initGeometry( void )
{
	std::cout << "initializing geometry" << std::endl;

	// Create a vertex array object
	GLuint vao;
	#ifdef __APPLE__
		glGenVertexArraysAPPLE( 1, &vao );
		glBindVertexArrayAPPLE( vao );
	#else
		// if it crashes here, it could be because VertexArrays aren't supported
		// on your card, but perhaps an extension is available
		glGenVertexArrays( 1, &vao );
		glBindVertexArray( vao );
	#endif

	// get attribute locations for use by all LitMesh derived classes
	LitCubeMesh::initAttributeLocations(program);
	
	cube.init();
	teapot.init();

	sphere.init(sphereSubdivisions);
	cylinder.init(12, 3);
	
	
	light.setSpecular(vec4(1, 1, 1, 1));
	light.setDiffuse(vec4(0.8,0.8,0.8,1));
	light.setAmbient(vec4(0.2, 0.2, 0.2, 1));

	visualizeNormalsMaterial.setEmissive(vec4(1,1,1,1));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// dolly camera in and out
float dolly = 6;

// for adjusting projection matrix on resize
float aspectRatio = 1.0;

// pick a mesh to show
int meshToShow = 0;

// hide or show normals
bool visualizeNormals = false;

void display( void )
{
	// rotate the light according to the trackball
	vec4 lightPos = transpose(arcballLight.rot) * vec4(0,0,4,1);

	switch(lightType)
	{
	// directional light
	case 0:
		lightPos.w = 0;
		light.setPosition(lightPos);
		break;
	// point light
	case 1:
		light.setPosition(lightPos);
		break;
	}

	 // clear the window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// the 'projection' matrix 
	mat4 Projection  = Perspective(30, aspectRatio, 1, 50);
	glUniformMatrix4fv(uniformId_projection, 1, GL_TRUE, Projection);

	// simple fixed camera that can dolly in and out 
	vec4 dir = vec4(0,0,0,1) + normalize(vec4(1,1,1,0)) * dolly;
	mat4 View = LookAt(dir, vec4(0,0,0,1), vec4(0,1,0,0));

	Material material;
	material.setSpecular(vec4(0,1,1,1));
	material.setSpecularExp(20);
	material.setAmbient(vec4(0,0.0,1,1));
	material.setDiffuse(vec4(0,0.8,0.2,1));

	// send lighting parameters to the shader
	light.sendUniforms(View);

	// send material parameters to the shader
	material.sendUniforms();

	// send the model view matrix (without projection!!)
	mat4 ModelView = View;
	// remember TRS order
	ModelView *= Translate(X,Y,Z);
	ModelView *= transpose(arcballModel.rot);
	ModelView *= Scale(U,V,W);

	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, ModelView);

	// send the transpose of the inverse of the model view as well for normals
	mat4 NM = transpose(affineInverse(ModelView));
	mat3 NormalMatrix = mat3(NM[0][0],NM[0][1],NM[0][2],
							NM[1][0],NM[1][1],NM[1][2],
							NM[2][0],NM[2][1],NM[2][2]);
	glUniformMatrix3fv(uniformId_normalMatrix, 1, GL_TRUE, NormalMatrix);

	// draw mesh and optionally visualize normals
	switch(meshToShow)
	{
 
	case 0:
		sphere.draw();
		if (visualizeNormals)
		{
			visualizeNormalsMaterial.sendUniforms();
			sphere.visualizeNormals();
		}
		break;

	case 1:
		teapot.draw();
		if (visualizeNormals)
		{
			visualizeNormalsMaterial.sendUniforms();
			teapot.visualizeNormals();
		}
		break;

	case 2:
		cylinder.draw();
		if (visualizeNormals)
		{
			visualizeNormalsMaterial.sendUniforms();
			cylinder.visualizeNormals();
		}
		break;
	
	case 3:
		cube.draw();
		if (visualizeNormals)
		{
			visualizeNormalsMaterial.sendUniforms();
			cube.visualizeNormals();
		}
		break;
	}

	//CHECK_GL_ERROR;

	// swap buffers and display
	glutSwapBuffers();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// current window width and height
int winHeight;
int winWidth;

void reshape(int width, int height)
{
	std::cout << "reshape " << width << " by " << height << std::endl;

	winWidth = width;
	winHeight = height;

	// update the aspect ratio for the Projection matrix
	aspectRatio = width / (float)height;

	// update the viewport to fit the entire area
	glViewport(0, 0, width, height);

	arcballLight.set_params(vec2(width / 2, height / 2), std::min(width,height) / 2 ); 
	arcballModel.set_params(vec2(width / 2, height / 2), std::min(width,height) / 3 ); 
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// keyboard event callback function
bool fillAsLines = false;
int lineWidth = 1;

// amt to dolly camera in and out
float DOLLY_BY = 1.0;

void keyboard( unsigned char key, int x, int y )
{
	switch ( key )
	{
		// Esc key
		case 033:
			exit( EXIT_SUCCESS );
			break;

		case '_':
			fillAsLines = ! fillAsLines;
			if (fillAsLines)
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			else
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			break;

		case '-':
			dolly += DOLLY_BY;
			break;

		case '+':
			dolly = std::max(1.0f, dolly - DOLLY_BY);
			break;

		case 'c':
			if (glIsEnabled(GL_CULL_FACE))
				glDisable(GL_CULL_FACE);
			else
				glEnable(GL_CULL_FACE);
			break;

		case 'n':
			visualizeNormals = ! visualizeNormals;
			break;

		case '.':
			lightType = (lightType + 1) % 2;
			break;

		case ',':
			meshToShow = (meshToShow + 1) % 4;
			break;

		// increase and decrease sphere subdivision
		case 's':
			sphereSubdivisions = std::max(0, sphereSubdivisions - 1);
			sphere.init(sphereSubdivisions);
			break;

		case 'S':
			// anything more than 6 is going to take a long time
			sphereSubdivisions = std::min(99, sphereSubdivisions + 1);
			sphere.init(sphereSubdivisions);
			break;

		// toggle light or model rotation with arcball
		case ' ':
			if (arcball == &arcballModel)
				arcball = &arcballLight;
			else
				arcball = &arcballModel;
	}

	adjustable.key(key, x, y);
	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// non ASCII keyboard event callback
void specialKeyboard(int key, int x, int y)
{
	std::string result = adjustable.specialKey(key, x, y);
	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void mouse(int button, int state, int x, int y)
{
	if (state == GLUT_DOWN)
	{
		arcball->mouse_down(x, winHeight - y);
	}
	else if (state == GLUT_UP)
	{
		arcball->mouse_up();
	}
	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void mouseDrag(int x, int y)
{
	int mod = glutGetModifiers();

	arcball->mouse_motion(x, winHeight - y, 
		mod == GLUT_ACTIVE_SHIFT, mod == GLUT_ACTIVE_CTRL, mod == GLUT_ACTIVE_ALT);
	glutPostRedisplay();

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void idle()
{
	arcballModel.idle();
	arcballLight.idle();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// application entry point
int	main( int argc, char **argv )
{
	// initialize glut
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA );
	glutInitWindowSize( 512, 512 );

	#ifndef __APPLE__
	// If you are using freeglut extensions, ask for an OpenGL
	// version context
    glutInitContextVersion( 2, 1 );
	// this seems to force the most recent version, but would be nice
	// to call since it forces modern OpenGL calls
	//glutInitContextFlags (GLUT_FORWARD_COMPATIBLE );
    //glutInitContextProfile( GLUT_CORE_PROFILE );
	#endif
	// create the window
	glutCreateWindow( "Demo" );

	#ifndef __APPLE__
	// initialize the OpenGL extension wrangler
	glewExperimental = GL_TRUE; // seems to help with older contexts
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		std::cerr << "GLEW Error: " << glewGetErrorString(err) << std::endl;
		return 1;
	}
	#endif

	// query for version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	// set window background colour
	glClearColor( 0.4, 0.4, 0.4, 1.0 );

	// enable depth testing
	glEnable(GL_DEPTH_TEST);

	// blending and smoothing
	glEnable(GL_BLEND); 
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint( GL_LINE_SMOOTH_HINT, GL_NICEST );
	glHint( GL_POLYGON_SMOOTH_HINT, GL_NICEST );

	// load shaders into the GPU
	initShaders();

	// create geometry and put it into the GPU
	initGeometry();

	// set event callback functions
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( keyboard );
	glutSpecialFunc( specialKeyboard );

	glutIdleFunc(idle);

	glutMouseFunc(mouse);
	glutMotionFunc(mouseDrag);

	// link adjustable parameters
	adjustable.add(&X, 'x', "X");
	adjustable.add(&Y, 'y', "Y");	
	adjustable.add(&Y, 'y', "Y");	

	adjustable.add(&U, 'u', "U");	
	adjustable.add(&V, 'v', "V");	
	adjustable.add(&W, 'w', "W");	

	arcball = &arcballModel;

	std::cout << "initializing done" << std::endl;

	// enter the main loop
	glutMainLoop();

	// should never get to this point
	return 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
