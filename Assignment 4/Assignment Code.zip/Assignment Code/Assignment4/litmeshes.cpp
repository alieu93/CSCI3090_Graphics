#include "litmeshes.h"

#include "gl_utilities.h"

#include "teapot.h"

namespace djv {

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

GLint LitMesh::attributeId_vPosition = -1;
GLint LitMesh::attributeId_vNormal = -1;


void LitMesh::initAttributeLocations(GLuint program)
{
	attributeId_vPosition  = glGetAttribLocationHelper(program, "vPosition");
	glEnableVertexAttribArray(attributeId_vPosition);
	attributeId_vNormal  = glGetAttribLocationHelper(program, "vNormal");
	glEnableVertexAttribArray(attributeId_vNormal);
}

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =



// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =


// a,b,c,d must be given in CCW order
void LitMesh::addQuadFace(vec3 a, vec3 b, vec3 c, vec3 d, vec3 n, 
					      std::vector< Vertex >* vertices, 
						  std::vector< GLushort >* indices,
						  std::vector< vec3 >* visualizeNormals  )
{

	// CCW order 
	// (not necessarily with a in bottom left, could be rotated)
	//  d-------c 
	//  |       | 
	//  |       |
	//  |       |
	//  a-------b

	int i = vertices->size();

	// add the vertices
	vertices->push_back(Vertex(a, n));
	vertices->push_back(Vertex(b, n));
	vertices->push_back(Vertex(c, n));
	vertices->push_back(Vertex(d, n));

	// add the indices for two triangles
	indices->push_back(i);
	indices->push_back(i+1);
	indices->push_back(i+2);

	indices->push_back(i);
	indices->push_back(i+2);
	indices->push_back(i+3);

	// optional, but useful for debugging normals
	// create some vertices to draw lines to visualize this
	// surface's normal
	if (visualizeNormals != NULL)
	{
		// find centre point
		vec3 p = a + 0.5 * (d- a) + 0.5 * (b - a);

		// add vertices for the normal visualization
		visualizeNormals->push_back(p);
		visualizeNormals->push_back(p + 0.25 * n);
	}
}


void LitCubeMesh::init()
{

	//    v7----- v6
	//   /|      /|
	//  v3------v2|
	//  | |     | |
	//  | |v4---|-|v5
	//  |/      |/
	//  v0------v1

	// the vertices that make up a cube
	vec3 v[] = {
			vec3( -0.5f, -0.5f,  0.5f ),  // v0
			vec3(  0.5f, -0.5f,  0.5f ),  // v1
			vec3(  0.5f,  0.5f,  0.5f ),  // v2
			vec3( -0.5f,  0.5f,  0.5f ),  // v3
			vec3( -0.5f, -0.5f, -0.5f ),  // v4
			vec3(  0.5f, -0.5f, -0.5f ),  // v5
			vec3(  0.5f,  0.5f, -0.5f ),  // v6
			vec3( -0.5f,  0.5f, -0.5f )   // v7
	};

	// to light the cube, we need to create faces with normals
	// these are the 'actual' vertices we send to the GPU
	std::vector< Vertex > vertices;
	std::vector< GLushort > indices;

	std::vector< vec3 > visualizeNormals;

	vec3 n;


	// front 
	n = vec3(0,0,1);
	addQuadFace(v[0],v[1],v[2],v[3], n, &vertices, &indices, &visualizeNormals);

	// right
	n = vec3(1,0,0);
	addQuadFace(v[1],v[5],v[6],v[2], n, &vertices, &indices, &visualizeNormals);

	// left
	n = vec3(-1,0,0);
	addQuadFace(v[4],v[0],v[3],v[7], n, &vertices, &indices, &visualizeNormals);

	// back
	n = vec3(0,0,-1);
	addQuadFace(v[5],v[4],v[7],v[6], n, &vertices, &indices, &visualizeNormals);

	// top
	n = vec3(0,1,0);
	addQuadFace(v[3],v[2],v[6],v[7], n, &vertices, &indices, &visualizeNormals);

	// bottom
	n = vec3(0,-1,0);
	addQuadFace(v[0],v[4],v[5],v[1], n, &vertices, &indices, &visualizeNormals);

	drawNum = indices.size();

	vertexStride = sizeof(vertices[0]);
	normalOffset = sizeof(vertices[0].vertex);

	visualizeNormalsDrawNum = visualizeNormals.size();


	// Create vertex buffer
	glGenBuffers(1, &bufferId_vertices);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), 
			&vertices.front(), GL_STATIC_DRAW);

	// Create index buffer
	glGenBuffers(1, &bufferId_indices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), 
			&indices.front(), GL_STATIC_DRAW);

	// Create normal visualization buffer
	glGenBuffers(1, &bufferId_visualizeNormals);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glBufferData(GL_ARRAY_BUFFER, sizeof(visualizeNormals[0]) * visualizeNormals.size(), 
			&visualizeNormals.front(), GL_STATIC_DRAW);

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitCubeMesh::draw()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);

	// map the buffer data to attribute locations
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(0));
	glVertexAttribPointer(LitMesh::attributeId_vNormal, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(normalOffset));

	// draw the mesh
	glDrawElements(GL_TRIANGLES, drawNum, GL_UNSIGNED_SHORT, NULL);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitCubeMesh::visualizeNormals()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		0, BUFFER_OFFSET(0));
	glDrawArrays(GL_LINES, 0, visualizeNormalsDrawNum);

}

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

void LitSphereMesh::init(int n)
{
	std::vector< vec4 > vertices;

	// 4 points on a tetrahedron
	vec4 v[4]= {	vec4(0.0, 0.0, 1.0, 1.0), 
					vec4(0.0, 0.942809, -0.333333, 1.0),
					vec4(-0.816497, -0.471405, -0.333333, 1.0),
					vec4(0.816497, -0.471405, -0.333333, 1.0) 	};

	// recursive subdivision, add to vertex list
	std::vector< vec4 > t;
	t =	divide_triangle(v[0], v[1], v[2] , n);
	vertices.insert( vertices.end(), t.begin(), t.end() );
	t = divide_triangle(v[3], v[2], v[1], n );
	vertices.insert( vertices.end(), t.begin(), t.end() );
	t = divide_triangle(v[0], v[3], v[1], n );
	vertices.insert( vertices.end(), t.begin(), t.end() );
	t = divide_triangle(v[0], v[2], v[3], n );
	vertices.insert( vertices.end(), t.begin(), t.end() );

	// put sphere vertices in buffer
	glGenBuffers(1, &bufferId_vertices);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices.front(), GL_STATIC_DRAW);
	vertexStride = sizeof(vertices[0]);
	drawNum = vertices.size();


	// create lines to visualize normals
	std::vector< vec3 > visualizeNormals;

	for (int i = 0; i < vertices.size(); i++)
	{
		vec4 v4 = vertices[i];
		vec3 v(v4.x, v4.y, v4.z);

		visualizeNormals.push_back(v);
		visualizeNormals.push_back(v + (0.3 * v));
	}

	visualizeNormalsDrawNum = visualizeNormals.size();

	// load into normal visualization buffer
	glGenBuffers(1, &bufferId_visualizeNormals);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glBufferData(GL_ARRAY_BUFFER, sizeof(visualizeNormals[0]) * visualizeNormals.size(), 
			&visualizeNormals.front(), GL_STATIC_DRAW);

	std::cout << "Init sphere with " << n << " subdivisions resulting in " << vertices.size() << " vertices." << std::endl;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

std::vector< vec4 > LitSphereMesh::divide_triangle(vec4 a, vec4 b, vec4 c, int n)
{
	std::vector< vec4 > vertices;
	vec4 v1, v2, v3;
	// recurse
	if(n > 0)
	{
		v1 = unit(a + b);
		v2 = unit(a + c);
		v3 = unit(b + c);   

		std::vector< vec4 > t;
		t =	divide_triangle(a ,v2, v1, n-1);
		vertices.insert( vertices.end(), t.begin(), t.end() );
		t = divide_triangle(c ,v3, v2, n-1);
		vertices.insert( vertices.end(), t.begin(), t.end() );
		t = divide_triangle(b ,v1, v3, n-1);
		vertices.insert( vertices.end(), t.begin(), t.end() );
		t = divide_triangle(v1 ,v2, v3, n-1);
		vertices.insert( vertices.end(), t.begin(), t.end() );
		return vertices;
	}
	// end recursion
	else 
	{
		// just create a triangle and return it
		std::vector< vec4 > t;
		t.push_back(a);
		t.push_back(b);
		t.push_back(c);
		//t =	triangle(a, b, c);
		vertices.insert( vertices.end(), t.begin(), t.end() );
		return vertices;
	}
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// helper function to 'push' vertex to circle 
vec4 LitSphereMesh::unit(const vec4 &p)
{
	vec4 c;
	double d = 0.0f;
	for(int i=0; i < 3; i++) 
	{
		d += p[i] * p[i];
	}
	d = sqrt(d);
	if(d > 0.0) 
	{
		for(int i=0; i<3; i++)
		{
			c[i] = p[i] / d;
		}
	}
	c[3] = 1.0f;
	return c;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitSphereMesh::draw()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);

	// map the buffer data to attribute locations
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 4, GL_FLOAT, GL_FALSE, 
		0, BUFFER_OFFSET(0));
	glVertexAttribPointer(LitMesh::attributeId_vNormal, 4, GL_FLOAT, GL_FALSE, 
		0, BUFFER_OFFSET(0));

	// draw the mesh
	glDrawArrays(GL_TRIANGLES, 0, drawNum);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitSphereMesh::visualizeNormals()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		0, BUFFER_OFFSET(0));
	glDrawArrays(GL_LINES, 0, visualizeNormalsDrawNum);

}

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

void LitCylinderMesh::init(int facets, int segments)
{
	std::vector< Vertex > vertices;

	vec3 n; // vertex normal

	// top face vertices first
	n = vec3(0,1,0);

	// centre
	vertices.push_back(Vertex(vec3(0,0.5,0),n));
	 
	//ring
	for(int f = 0; f < facets; f++)
	{
		float angle_rad = (float)f / (float)facets * (float)(2.0f * M_PI);
		vec3 v(sin(angle_rad) * 0.5f, 0.5, cos(angle_rad) * 0.5f);
		vertices.push_back(Vertex(v, n));
	}

	// bottom face vertices next
	n = vec3(0,-1,0);

	// centre
	vertices.push_back(Vertex(vec3(0,-0.5,0), vec3(0,-1,0)));

	//ring
	for(int f = 0; f < facets; f++)
	{
		float angle_rad = (float)f / (float)facets * (float)(2.0f * M_PI);
		vec3 v(sin(angle_rad) * 0.5f, -0.5, cos(angle_rad) * 0.5f);
		vertices.push_back(Vertex(v, n));
	}

	// side vertices

	// compute segment spacing
	float seg_space = 1.0f / (float)segments;

	// start at the top layer
	float top = 0.5; 

	// create rings of vertices for each segment
	for(int s = 0; s <= segments; s++)
	{
		float layer = top - (s * seg_space);

		for(int f = 0; f < facets; f++)
		{
			float angle_rad = (float)f / (float)facets * (float)(2.0f * M_PI);
			vec3 v(sin(angle_rad) * 0.5f, layer, cos(angle_rad) * 0.5f);
			n = vec3(sin(angle_rad), 0, cos(angle_rad)); 
			vertices.push_back(Vertex(v, n));
		}
	}

	// create the mesh triangles
	// could use a fan for the top and bottom and strips for the sides
	// but then you need multiple glDraw calls
	// often easiest to just make triangles

	// create indices for filled cylinder
	std::vector< GLushort > indices;

	// top cap
	int center = 0;
	int offset = center + 1;
	for(int f = 0; f < facets; f++)
	{
		// CCW triangle from top
		indices.push_back(center);
		int i = f + offset;
		indices.push_back(i);
		indices.push_back(f < facets - 1 ? i + 1 : offset);

	}

	// bottom cap
	center = 1 + facets;
	offset = center + 1;
	for(int f = 0; f < facets; f++)
	{
		// CCW triangle from bottom
		indices.push_back(center);
		int i = f + offset;
		indices.push_back(f < facets - 1 ? i + 1 : offset);
		indices.push_back(i);
	}

	

	// sides
	for(int s = 0; s < segments; s++)
	{
		offset = 2 * (facets + 1)  + (facets * s);
		for(int f = 0; f < facets; f++)
		{
			int i = f + offset;

			int iPlus1 = f < facets - 1 ? i + 1 : offset;

			// triangle 1
			indices.push_back(i);
			indices.push_back(i + facets);
			indices.push_back(iPlus1);


			// triangle 2
			indices.push_back(iPlus1);
			indices.push_back(i + facets);
			indices.push_back(iPlus1 + facets);

		}
	}

	for (unsigned int i=0; i < indices.size(); i++)
	{
		if (indices[i] >  vertices.size() - 1 )
		{
			std::cout << "index error" << std::endl;
		}
	}

	drawNum = indices.size();
	vertexStride = sizeof(vertices[0]);
	normalOffset = sizeof(vertices[0].vertex);

	// load all the buffers
	
	// load into vertex buffer
	glGenBuffers(1, &bufferId_vertices);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices[0]) * vertices.size(), &vertices.front(), GL_STATIC_DRAW);

	// load into the vertex buffer
	drawNum = indices.size();
	glGenBuffers(1, &bufferId_indices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(indices[0]) * indices.size(), &indices.front(), GL_STATIC_DRAW);

	// create lines to visualize normals
	std::vector< vec3 > visualizeNormals;

	for (int i = 0; i < vertices.size(); i++)
	{
		vec3 v = vertices[i].vertex;
		vec3 n = vertices[i].normal;
		visualizeNormals.push_back(v);
		visualizeNormals.push_back(v + (0.3 * n));
	}

	visualizeNormalsDrawNum = visualizeNormals.size();

	// load into normal visualization buffer
	glGenBuffers(1, &bufferId_visualizeNormals);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glBufferData(GL_ARRAY_BUFFER, sizeof(visualizeNormals[0]) * visualizeNormals.size(), 
			&visualizeNormals.front(), GL_STATIC_DRAW);

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitCylinderMesh::draw()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);

	// map the buffer data to attribute locations
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(0));
	glVertexAttribPointer(LitMesh::attributeId_vNormal, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(normalOffset));

	// draw the mesh
	glDrawElements(GL_TRIANGLES, drawNum, GL_UNSIGNED_SHORT, NULL);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitCylinderMesh::visualizeNormals()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		0, BUFFER_OFFSET(0));
	glDrawArrays(GL_LINES, 0, visualizeNormalsDrawNum);

}


void LitTeapotMesh::init()
{
	vertexStride = 3 * sizeof(teapotVertices[0]);
	normalOffset = 0;
	drawNum = sizeof(teapotIndices)/sizeof(teapotIndices[0]);

	// Create vertex buffer
	glGenBuffers(1, &bufferId_vertices);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBufferData(GL_ARRAY_BUFFER, sizeof(teapotVertices) + sizeof(teapotNormals),0, GL_STREAM_DRAW);
	glBufferSubData(GL_ARRAY_BUFFER, 0, sizeof(teapotVertices), teapotVertices);
	glBufferSubData(GL_ARRAY_BUFFER, sizeof(teapotVertices), sizeof(teapotNormals), teapotNormals);

	// for the teapot, the normals are stored after the vertices, not interleaved
	normalOffset = sizeof(teapotVertices);
	
	// Create index buffer
	glGenBuffers(1, &bufferId_indices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(teapotIndices), 
			teapotIndices, GL_STATIC_DRAW);

	// create lines to visualize normals
	std::vector< vec3 > visualizeNormals;

	int countVertices = sizeof(teapotVertices)/(3*sizeof(teapotVertices[0]));
	
	for (int i = 0; i < countVertices; i++)
	{
		vec3 v = vec3(teapotVertices[i*3],teapotVertices[i*3+1],teapotVertices[i*3+2]);
		vec3 n = vec3(teapotNormals[i*3],teapotNormals[i*3+1],teapotNormals[i*3+2]);
		visualizeNormals.push_back(v);
		visualizeNormals.push_back(v + (0.3 * n));
	}

	visualizeNormalsDrawNum = visualizeNormals.size();

	// load into normal visualization buffer
	glGenBuffers(1, &bufferId_visualizeNormals);
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glBufferData(GL_ARRAY_BUFFER, sizeof(visualizeNormals[0]) * visualizeNormals.size(), 
			&visualizeNormals.front(), GL_STATIC_DRAW);
	
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitTeapotMesh::draw()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_vertices);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, bufferId_indices);

	// map the buffer data to attribute locations
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(0));
	glVertexAttribPointer(LitMesh::attributeId_vNormal, 3, GL_FLOAT, GL_FALSE, 
		vertexStride, BUFFER_OFFSET(normalOffset));

	// draw the mesh
	glDrawElements(GL_TRIANGLE_STRIP, 12, GL_UNSIGNED_SHORT, (GLushort*)0+0);
	glDrawElements(GL_TRIANGLE_STRIP, 78, GL_UNSIGNED_SHORT, (GLushort*)0+12);
	glDrawElements(GL_TRIANGLE_STRIP, 35, GL_UNSIGNED_SHORT, (GLushort*)0+90);
	glDrawElements(GL_TRIANGLE_STRIP, 70, GL_UNSIGNED_SHORT, (GLushort*)0+125);
	glDrawElements(GL_TRIANGLE_STRIP, 65, GL_UNSIGNED_SHORT, (GLushort*)0+195);
	glDrawElements(GL_TRIANGLE_STRIP, 37, GL_UNSIGNED_SHORT, (GLushort*)0+260);
	glDrawElements(GL_TRIANGLE_STRIP, 35, GL_UNSIGNED_SHORT, (GLushort*)0+297);
	glDrawElements(GL_TRIANGLE_STRIP, 32, GL_UNSIGNED_SHORT, (GLushort*)0+332);
	glDrawElements(GL_TRIANGLE_STRIP, 56, GL_UNSIGNED_SHORT, (GLushort*)0+364);
	glDrawElements(GL_TRIANGLE_STRIP, 45, GL_UNSIGNED_SHORT, (GLushort*)0+420);
	glDrawElements(GL_TRIANGLE_STRIP, 41, GL_UNSIGNED_SHORT, (GLushort*)0+465);
	glDrawElements(GL_TRIANGLE_STRIP, 37, GL_UNSIGNED_SHORT, (GLushort*)0+506);
	glDrawElements(GL_TRIANGLE_STRIP, 33, GL_UNSIGNED_SHORT, (GLushort*)0+543);
	glDrawElements(GL_TRIANGLE_STRIP, 29, GL_UNSIGNED_SHORT, (GLushort*)0+576);
	glDrawElements(GL_TRIANGLE_STRIP, 25, GL_UNSIGNED_SHORT, (GLushort*)0+605);
	glDrawElements(GL_TRIANGLE_STRIP, 21, GL_UNSIGNED_SHORT, (GLushort*)0+630);
	glDrawElements(GL_TRIANGLE_STRIP, 17, GL_UNSIGNED_SHORT, (GLushort*)0+651);
	glDrawElements(GL_TRIANGLE_STRIP, 13, GL_UNSIGNED_SHORT, (GLushort*)0+668);
	glDrawElements(GL_TRIANGLE_STRIP, 9, GL_UNSIGNED_SHORT, (GLushort*)0+681);
	glDrawElements(GL_TRIANGLE_STRIP, 27, GL_UNSIGNED_SHORT, (GLushort*)0+690);
	glDrawElements(GL_TRIANGLE_STRIP, 16, GL_UNSIGNED_SHORT, (GLushort*)0+717);
	glDrawElements(GL_TRIANGLE_STRIP, 22, GL_UNSIGNED_SHORT, (GLushort*)0+733);
	glDrawElements(GL_TRIANGLE_STRIP, 50, GL_UNSIGNED_SHORT, (GLushort*)0+755);
	glDrawElements(GL_TRIANGLE_STRIP, 42, GL_UNSIGNED_SHORT, (GLushort*)0+805);
	glDrawElements(GL_TRIANGLE_STRIP, 43, GL_UNSIGNED_SHORT, (GLushort*)0+847);
	glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_SHORT, (GLushort*)0+890);
	glDrawElements(GL_TRIANGLE_STRIP, 143, GL_UNSIGNED_SHORT, (GLushort*)0+894);
	glDrawElements(GL_TRIANGLE_STRIP, 234, GL_UNSIGNED_SHORT, (GLushort*)0+1037);
	glDrawElements(GL_TRIANGLE_STRIP, 224, GL_UNSIGNED_SHORT, (GLushort*)0+1271);
	glDrawElements(GL_TRIANGLE_STRIP, 71, GL_UNSIGNED_SHORT, (GLushort*)0+1495);
	glDrawElements(GL_TRIANGLE_STRIP, 69, GL_UNSIGNED_SHORT, (GLushort*)0+1566);
	glDrawElements(GL_TRIANGLE_STRIP, 67, GL_UNSIGNED_SHORT, (GLushort*)0+1635);
	glDrawElements(GL_TRIANGLE_STRIP, 65, GL_UNSIGNED_SHORT, (GLushort*)0+1702);
	glDrawElements(GL_TRIANGLE_STRIP, 63, GL_UNSIGNED_SHORT, (GLushort*)0+1767);
	glDrawElements(GL_TRIANGLE_STRIP, 61, GL_UNSIGNED_SHORT, (GLushort*)0+1830);
	glDrawElements(GL_TRIANGLE_STRIP, 59, GL_UNSIGNED_SHORT, (GLushort*)0+1891);
	glDrawElements(GL_TRIANGLE_STRIP, 57, GL_UNSIGNED_SHORT, (GLushort*)0+1950);
	glDrawElements(GL_TRIANGLE_STRIP, 55, GL_UNSIGNED_SHORT, (GLushort*)0+2007);
	glDrawElements(GL_TRIANGLE_STRIP, 53, GL_UNSIGNED_SHORT, (GLushort*)0+2062);
	glDrawElements(GL_TRIANGLE_STRIP, 51, GL_UNSIGNED_SHORT, (GLushort*)0+2115);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+2166);
	glDrawElements(GL_TRIANGLE_STRIP, 50, GL_UNSIGNED_SHORT, (GLushort*)0+2169);
	glDrawElements(GL_TRIANGLE_STRIP, 48, GL_UNSIGNED_SHORT, (GLushort*)0+2219);
	glDrawElements(GL_TRIANGLE_STRIP, 46, GL_UNSIGNED_SHORT, (GLushort*)0+2267);
	glDrawElements(GL_TRIANGLE_STRIP, 44, GL_UNSIGNED_SHORT, (GLushort*)0+2313);
	glDrawElements(GL_TRIANGLE_STRIP, 42, GL_UNSIGNED_SHORT, (GLushort*)0+2357);
	glDrawElements(GL_TRIANGLE_STRIP, 40, GL_UNSIGNED_SHORT, (GLushort*)0+2399);
	glDrawElements(GL_TRIANGLE_STRIP, 38, GL_UNSIGNED_SHORT, (GLushort*)0+2439);
	glDrawElements(GL_TRIANGLE_STRIP, 36, GL_UNSIGNED_SHORT, (GLushort*)0+2477);
	glDrawElements(GL_TRIANGLE_STRIP, 34, GL_UNSIGNED_SHORT, (GLushort*)0+2513);
	glDrawElements(GL_TRIANGLE_STRIP, 32, GL_UNSIGNED_SHORT, (GLushort*)0+2547);
	glDrawElements(GL_TRIANGLE_STRIP, 30, GL_UNSIGNED_SHORT, (GLushort*)0+2579);
	glDrawElements(GL_TRIANGLE_STRIP, 28, GL_UNSIGNED_SHORT, (GLushort*)0+2609);
	glDrawElements(GL_TRIANGLE_STRIP, 26, GL_UNSIGNED_SHORT, (GLushort*)0+2637);
	glDrawElements(GL_TRIANGLE_STRIP, 24, GL_UNSIGNED_SHORT, (GLushort*)0+2663);
	glDrawElements(GL_TRIANGLE_STRIP, 22, GL_UNSIGNED_SHORT, (GLushort*)0+2687);
	glDrawElements(GL_TRIANGLE_STRIP, 20, GL_UNSIGNED_SHORT, (GLushort*)0+2709);
	glDrawElements(GL_TRIANGLE_STRIP, 18, GL_UNSIGNED_SHORT, (GLushort*)0+2729);
	glDrawElements(GL_TRIANGLE_STRIP, 16, GL_UNSIGNED_SHORT, (GLushort*)0+2747);
	glDrawElements(GL_TRIANGLE_STRIP, 14, GL_UNSIGNED_SHORT, (GLushort*)0+2763);
	glDrawElements(GL_TRIANGLE_STRIP, 12, GL_UNSIGNED_SHORT, (GLushort*)0+2777);
	glDrawElements(GL_TRIANGLE_STRIP, 10, GL_UNSIGNED_SHORT, (GLushort*)0+2789);
	glDrawElements(GL_TRIANGLE_STRIP, 8, GL_UNSIGNED_SHORT, (GLushort*)0+2799);
	glDrawElements(GL_TRIANGLE_STRIP, 6, GL_UNSIGNED_SHORT, (GLushort*)0+2807);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+2813);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+2816);
	glDrawElements(GL_TRIANGLE_STRIP, 200, GL_UNSIGNED_SHORT, (GLushort*)0+2819);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3019);
	glDrawElements(GL_TRIANGLE_STRIP, 66, GL_UNSIGNED_SHORT, (GLushort*)0+3022);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3088);
	glDrawElements(GL_TRIANGLE_STRIP, 209, GL_UNSIGNED_SHORT, (GLushort*)0+3091);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3300);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3303);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3306);
	glDrawElements(GL_TRIANGLE_STRIP, 38, GL_UNSIGNED_SHORT, (GLushort*)0+3309);
	glDrawElements(GL_TRIANGLE_STRIP, 15, GL_UNSIGNED_SHORT, (GLushort*)0+3347);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3362);
	glDrawElements(GL_TRIANGLE_STRIP, 26, GL_UNSIGNED_SHORT, (GLushort*)0+3365);
	glDrawElements(GL_TRIANGLE_STRIP, 9, GL_UNSIGNED_SHORT, (GLushort*)0+3391);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3400);
	glDrawElements(GL_TRIANGLE_STRIP, 14, GL_UNSIGNED_SHORT, (GLushort*)0+3403);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3417);
	glDrawElements(GL_TRIANGLE_STRIP, 115, GL_UNSIGNED_SHORT, (GLushort*)0+3420);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3535);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3538);
	glDrawElements(GL_TRIANGLE_STRIP, 39, GL_UNSIGNED_SHORT, (GLushort*)0+3541);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3580);
	glDrawElements(GL_TRIANGLE_STRIP, 91, GL_UNSIGNED_SHORT, (GLushort*)0+3583);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3674);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3677);
	glDrawElements(GL_TRIANGLE_STRIP, 31, GL_UNSIGNED_SHORT, (GLushort*)0+3680);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3711);
	glDrawElements(GL_TRIANGLE_STRIP, 67, GL_UNSIGNED_SHORT, (GLushort*)0+3714);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3781);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3784);
	glDrawElements(GL_TRIANGLE_STRIP, 23, GL_UNSIGNED_SHORT, (GLushort*)0+3787);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3810);
	glDrawElements(GL_TRIANGLE_STRIP, 45, GL_UNSIGNED_SHORT, (GLushort*)0+3813);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3858);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3861);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3864);
	glDrawElements(GL_TRIANGLE_STRIP, 32, GL_UNSIGNED_SHORT, (GLushort*)0+3867);
	glDrawElements(GL_TRIANGLE_STRIP, 38, GL_UNSIGNED_SHORT, (GLushort*)0+3899);
	glDrawElements(GL_TRIANGLE_STRIP, 15, GL_UNSIGNED_SHORT, (GLushort*)0+3937);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3952);
	glDrawElements(GL_TRIANGLE_STRIP, 26, GL_UNSIGNED_SHORT, (GLushort*)0+3955);
	glDrawElements(GL_TRIANGLE_STRIP, 9, GL_UNSIGNED_SHORT, (GLushort*)0+3981);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+3990);
	glDrawElements(GL_TRIANGLE_STRIP, 14, GL_UNSIGNED_SHORT, (GLushort*)0+3993);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+4007);
	glDrawElements(GL_TRIANGLE_STRIP, 135, GL_UNSIGNED_SHORT, (GLushort*)0+4010);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+4145);
	glDrawElements(GL_TRIANGLE_STRIP, 76, GL_UNSIGNED_SHORT, (GLushort*)0+4148);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+4224);
	glDrawElements(GL_TRIANGLE_STRIP, 60, GL_UNSIGNED_SHORT, (GLushort*)0+4227);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+4287);
	glDrawElements(GL_TRIANGLE_STRIP, 23, GL_UNSIGNED_SHORT, (GLushort*)0+4290);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+4313);
	glDrawElements(GL_TRIANGLE_STRIP, 26, GL_UNSIGNED_SHORT, (GLushort*)0+4316);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+4342);
	glDrawElements(GL_TRIANGLE_STRIP, 6, GL_UNSIGNED_SHORT, (GLushort*)0+4345);
	glDrawElements(GL_TRIANGLE_STRIP, 947, GL_UNSIGNED_SHORT, (GLushort*)0+4351);
	glDrawElements(GL_TRIANGLE_STRIP, 35, GL_UNSIGNED_SHORT, (GLushort*)0+5298);
	glDrawElements(GL_TRIANGLE_STRIP, 31, GL_UNSIGNED_SHORT, (GLushort*)0+5333);
	glDrawElements(GL_TRIANGLE_STRIP, 27, GL_UNSIGNED_SHORT, (GLushort*)0+5364);
	glDrawElements(GL_TRIANGLE_STRIP, 23, GL_UNSIGNED_SHORT, (GLushort*)0+5391);
	glDrawElements(GL_TRIANGLE_STRIP, 20, GL_UNSIGNED_SHORT, (GLushort*)0+5414);
	glDrawElements(GL_TRIANGLE_STRIP, 24, GL_UNSIGNED_SHORT, (GLushort*)0+5434);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5458);
	glDrawElements(GL_TRIANGLE_STRIP, 28, GL_UNSIGNED_SHORT, (GLushort*)0+5461);
	glDrawElements(GL_TRIANGLE_STRIP, 32, GL_UNSIGNED_SHORT, (GLushort*)0+5489);
	glDrawElements(GL_TRIANGLE_STRIP, 36, GL_UNSIGNED_SHORT, (GLushort*)0+5521);
	glDrawElements(GL_TRIANGLE_STRIP, 76, GL_UNSIGNED_SHORT, (GLushort*)0+5557);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5633);
	glDrawElements(GL_TRIANGLE_STRIP, 67, GL_UNSIGNED_SHORT, (GLushort*)0+5636);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5703);
	glDrawElements(GL_TRIANGLE_STRIP, 59, GL_UNSIGNED_SHORT, (GLushort*)0+5706);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5765);
	glDrawElements(GL_TRIANGLE_STRIP, 51, GL_UNSIGNED_SHORT, (GLushort*)0+5768);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5819);
	glDrawElements(GL_TRIANGLE_STRIP, 43, GL_UNSIGNED_SHORT, (GLushort*)0+5822);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5865);
	glDrawElements(GL_TRIANGLE_STRIP, 35, GL_UNSIGNED_SHORT, (GLushort*)0+5868);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5903);
	glDrawElements(GL_TRIANGLE_STRIP, 27, GL_UNSIGNED_SHORT, (GLushort*)0+5906);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5933);
	glDrawElements(GL_TRIANGLE_STRIP, 19, GL_UNSIGNED_SHORT, (GLushort*)0+5936);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5955);
	glDrawElements(GL_TRIANGLE_STRIP, 11, GL_UNSIGNED_SHORT, (GLushort*)0+5958);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+5969);
	glDrawElements(GL_TRIANGLE_STRIP, 30, GL_UNSIGNED_SHORT, (GLushort*)0+5972);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+6002);
	glDrawElements(GL_TRIANGLE_STRIP, 11, GL_UNSIGNED_SHORT, (GLushort*)0+6005);
	glDrawElements(GL_TRIANGLE_STRIP, 18, GL_UNSIGNED_SHORT, (GLushort*)0+6016);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+6034);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_SHORT, (GLushort*)0+6037);
	glDrawElements(GL_TRIANGLE_STRIP, 5, GL_UNSIGNED_SHORT, (GLushort*)0+6040);
	glDrawElements(GL_TRIANGLE_STRIP, 122, GL_UNSIGNED_SHORT, (GLushort*)0+6045);
	glDrawElements(GL_TRIANGLE_STRIP, 75, GL_UNSIGNED_SHORT, (GLushort*)0+6167);
	glDrawElements(GL_TRIANGLE_STRIP, 71, GL_UNSIGNED_SHORT, (GLushort*)0+6242);
	glDrawElements(GL_TRIANGLE_STRIP, 67, GL_UNSIGNED_SHORT, (GLushort*)0+6313);
	glDrawElements(GL_TRIANGLE_STRIP, 63, GL_UNSIGNED_SHORT, (GLushort*)0+6380);
	glDrawElements(GL_TRIANGLE_STRIP, 59, GL_UNSIGNED_SHORT, (GLushort*)0+6443);
	glDrawElements(GL_TRIANGLE_STRIP, 55, GL_UNSIGNED_SHORT, (GLushort*)0+6502);
	glDrawElements(GL_TRIANGLE_STRIP, 51, GL_UNSIGNED_SHORT, (GLushort*)0+6557);
	glDrawElements(GL_TRIANGLE_STRIP, 47, GL_UNSIGNED_SHORT, (GLushort*)0+6608);
	glDrawElements(GL_TRIANGLE_STRIP, 43, GL_UNSIGNED_SHORT, (GLushort*)0+6655);
	glDrawElements(GL_TRIANGLE_STRIP, 39, GL_UNSIGNED_SHORT, (GLushort*)0+6698);
	glDrawElements(GL_TRIANGLE_STRIP, 35, GL_UNSIGNED_SHORT, (GLushort*)0+6737);
	glDrawElements(GL_TRIANGLE_STRIP, 31, GL_UNSIGNED_SHORT, (GLushort*)0+6772);
	glDrawElements(GL_TRIANGLE_STRIP, 27, GL_UNSIGNED_SHORT, (GLushort*)0+6803);
	glDrawElements(GL_TRIANGLE_STRIP, 23, GL_UNSIGNED_SHORT, (GLushort*)0+6830);
	glDrawElements(GL_TRIANGLE_STRIP, 19, GL_UNSIGNED_SHORT, (GLushort*)0+6853);
	glDrawElements(GL_TRIANGLE_STRIP, 15, GL_UNSIGNED_SHORT, (GLushort*)0+6872);
	glDrawElements(GL_TRIANGLE_STRIP, 11, GL_UNSIGNED_SHORT, (GLushort*)0+6887);
	glDrawElements(GL_TRIANGLE_STRIP, 7, GL_UNSIGNED_SHORT, (GLushort*)0+6898);

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void LitTeapotMesh::visualizeNormals()
{
	// bind the vertex and index buffers
	glBindBuffer(GL_ARRAY_BUFFER, bufferId_visualizeNormals);
	glVertexAttribPointer(LitMesh::attributeId_vPosition, 3, GL_FLOAT, GL_FALSE, 
		0, BUFFER_OFFSET(0));
	glDrawArrays(GL_LINES, 0, visualizeNormalsDrawNum);

}

// = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = = =

















}