/*
	Demos 5
	Daniel Vogel

	Portions may be adapted from:

	1) Suplemental code provided by Interactive Computer Graphics
	A Top-Down Approach with OpenGL, Edward Angel and Dave Shreiner
	Sixth Edition, Addison-Wesley 2012
	http://www.cs.unm.edu/~angel/BOOK/INTERACTIVE_COMPUTER_GRAPHICS/SIXTH_EDITION/CODE/

	2) From code supplied by http://openglbook.com/

	Copyright (C) 2011 by Eddy Luten

	Permission is hereby granted, free of charge, to any person obtaining a copy
	of this software and associated documentation files (the "Software"), to deal
	in the Software without restriction, including without limitation the rights
	to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
	copies of the Software, and to permit persons to whom the Software is
	furnished to do so, subject to the following conditions:

	The above copyright notice and this permission notice shall be included in
	all copies or substantial portions of the Software.

	THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
	IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
	FITNESS FOR A DEMOICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
	AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
	LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
	OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
	THE SOFTWARE.

*/

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

/*
	Demo Selection
	--------------
	Use the preprocessor define below to switch between
	different demos. If your editor supports outlining or
	can hide "inactive" code, it will make it easier to
	view individual demo code.

	DEMO 1: question 1
	DEMO 2: question 2

*/
#define DEMO 2

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#include <stdlib.h>

#include <iostream>
#include <sstream>
#include <string>

// stl variable array is called a vector
#include <vector>

// includes OpenGl libraries in a cross-platform way
#include "gl_include.h"

// include the helper files
#include "gl_utilities.h"

// include useful types for vectors and matricies
#include "vec.h"
#include "mat.h"




// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// use the djv namespace (avoid djv:: prefixes)
using namespace djv;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


// geometry
#include "meshes.h"

const int gridWidth = 10;
const int gridHeight = 10;
GridMesh grid(gridWidth, gridHeight, 1.0f);



GLuint program; // the OpenGL program "name"

// uniform variable 'name' ids 
GLint uniformId_colour;
GLint uniformId_modelView;

// initialize the vertex and fragment shaders
void initShaders(void)
{
	std::cout << "initializing shaders" << std::endl;

	program = loadAndInitializeShaders( "vshader7.glsl", "fshader2.glsl" );

	// get location id for uniform variables in shader program
	uniformId_colour = glGetUniformLocation(program, "in_Colour");
	uniformId_modelView = glGetUniformLocation(program, "modelView");
	glUseProgram( program );
}

GLint in_Position_loc;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#if DEMO == 1

GLuint vertex_buffer;
GLuint shape_1_buffer;
GLuint shape_2_buffer;
GLuint shape_3_buffer;
GLuint shape_4_buffer;

size_t stride;


void initGeometry( void )
{
	std::cout << "initializing geometry" << std::endl;

	// Create a vertex array object
	GLuint vao;
	#ifdef __APPLE__
		glGenVertexArraysAPPLE( 1, &vao );
		glBindVertexArrayAPPLE( vao );
	#else
		// if it crashes here, it could be because VertexArrays aren't supported
		// on your card, but perhaps an extension is available
		glGenVertexArrays( 1, &vao );
		glBindVertexArray( vao );
	#endif

	in_Position_loc = glGetAttribLocation( program, "in_Position" );
	glEnableVertexAttribArray(in_Position_loc);

	Mesh::in_position_loc = in_Position_loc;
	grid.init();

	// create vertices
	vec3 vertices[8] = { 
		vec3(0,0,0), vec3(1,0,0), vec3(1,1,0), vec3(0,1,0),
		vec3(0,0,1), vec3(1,0,1), vec3(1,1,1), vec3(0,1,1)};
	
	// Create vertex buffer
	glGenBuffers(1, &vertex_buffer);
	glBindBuffer(GL_ARRAY_BUFFER, vertex_buffer);
	glBufferData(GL_ARRAY_BUFFER,  sizeof(vertices), vertices, GL_STATIC_DRAW);

	// set the vertex buffer to attribute mapping
	glVertexAttribPointer(Mesh::in_position_loc, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	// create indices for different shapes
	GLubyte shape_1[3] = { 0, 1, 2 };
	GLubyte shape_2[3] = { 3, 2, 1 };
	GLubyte shape_3[3] = { 4, 5, 6 };
	GLubyte shape_4[3] = { 0, 3, 7 };

	// Create index buffers for each shape
	glGenBuffers(1, &shape_1_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_1_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,  sizeof(shape_1), shape_1, GL_STATIC_DRAW);

	glGenBuffers(1, &shape_2_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_2_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,  sizeof(shape_2), shape_2, GL_STATIC_DRAW);

	glGenBuffers(1, &shape_3_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_3_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,  sizeof(shape_3), shape_3, GL_STATIC_DRAW);

	glGenBuffers(1, &shape_4_buffer);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_4_buffer);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER,  sizeof(shape_4), shape_4, GL_STATIC_DRAW);
}

void drawShape(GLuint buffer, GLenum mode, mat4 M) {
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, M);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, buffer);
	glDrawElements(mode, 3, GL_UNSIGNED_BYTE, NULL);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

bool cullOn = false;
char part = 'e';

// display callback
void display( void )
{
	 // clear the window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// drawShape shapes
	glUniform4fv(uniformId_colour, 1, vec4(1.0f, 1.0f, 1.0f, 1.0f));  

	mat4 P = Ortho2D(-5,5,-5,5);

	switch (part)
	{
	case 'a':
		// drawShape the shape
		drawShape(shape_1_buffer, GL_LINE_LOOP, P);
		drawShape(shape_2_buffer, GL_LINE_LOOP, P);
		drawShape(shape_3_buffer, GL_LINE_LOOP, P);
		break;

	case 'b':
		{
		// drawShape the shape
mat4 M = RotateZ(45);
for (int i=0; i < 4; i++) {
	M = M * RotateZ(90);
	drawShape(shape_3_buffer, GL_LINE_LOOP, P * M);
}
		}
		break;

	case 'c':
		{
drawShape(shape_1_buffer, GL_LINE_LOOP, P);
drawShape(shape_4_buffer, GL_LINE_LOOP, P * RotateY(90));
drawShape(shape_2_buffer, GL_LINE_LOOP, P * 
	Translate(0.5, 1 + (sqrt(2.0)/2), 0) * 
	RotateZ(45) * Translate(-1, -1, 0));
		}
		break;

	case 'd':
		// drawShape the shape
glEnable(GL_CULL_FACE);
drawShape(shape_2_buffer, GL_TRIANGLES, P);
drawShape(shape_2_buffer, GL_TRIANGLES, P * RotateY(180));
		break;

	case 'e':
		{
glEnable(GL_DEPTH_TEST);
mat4 S = Scale(1.0, 1.0, 100);
drawShape(shape_2_buffer, GL_TRIANGLES, P * S);
drawShape(shape_3_buffer, GL_TRIANGLES, P * S);
		}
		break;


	}


	/*
 	// drawShape shape 1
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, P * Scale(4,4,0));
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_1_buffer);
	glDrawElements(GL_LINE_LOOP, 8, GL_UNSIGNED_BYTE, NULL);

	// drawShape shape 2
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, P * S);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_2_buffer);
	glDrawElements(GL_TRIANGLES, 4, GL_UNSIGNED_BYTE, NULL);

	// drawShape shape 3
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, P * Translate(-2,2,0));
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_3_buffer);
	glDrawElements(GL_TRIANGLES, 6, GL_UNSIGNED_BYTE, NULL);

	// drawShape shape 4
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, P * Translate(0,-2,0));
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, shape_4_buffer);
	glDrawElements(GL_TRIANGLES, 3, GL_UNSIGNED_BYTE, NULL);
	*/


	// clear the transform with the identity matrix
	
	//CHECK_GL_ERROR;

	// swap buffers and display
	glutSwapBuffers();
}


#elif DEMO == 2

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// for wireframe
GLuint circle_vertex_bufferId;
std::vector< vec2 > circle_vertices; 
GLuint square_vertex_bufferId;
std::vector< vec2 > square_vertices; 


void initGeometry( void )
{
	std::cout << "initializing geometry" << std::endl;

	// Create a vertex array object
	GLuint vao;
	#ifdef __APPLE__
		glGenVertexArraysAPPLE( 1, &vao );
		glBindVertexArrayAPPLE( vao );
	#else
		// if it crashes here, it could be because VertexArrays aren't supported
		// on your card, but perhaps an extension is available
		glGenVertexArrays( 1, &vao );
		glBindVertexArray( vao );
	#endif

	in_Position_loc = glGetAttribLocation( program, "in_Position" );
	glEnableVertexAttribArray(in_Position_loc);


	// wire circle geometry
	// - - - - - - - - - - - -

	int circle_vertex_num = 32;

	// add a centre vertex for the filled version of the circle
	// we'll drawShape it using a TRIANGLE_FAN and having the centre
	// point avoids sharp triangles
	// we won't drawShape it for the wireframe
	circle_vertices.push_back(vec2(0,0));

	// create diameter = 1 circle
	for(int i = circle_vertex_num; i > -1; i--)
	{
		float angle_rad = (float)i / (float)circle_vertex_num * (2.0f * M_PI);
		circle_vertices.push_back(vec2(sin(angle_rad), cos(angle_rad)) * 0.5f);
	}

	// add a final vertex for triangle fan
	// we won't drawShape it for the wireframe
	//circle_vertices.push_back(vec2(0,0.5));

	// another way to do this would be with indices, but we're only adding
	// 2 extra vertices

	// Create vertex buffer
	glGenBuffers(1, &circle_vertex_bufferId);
	glBindBuffer(GL_ARRAY_BUFFER, circle_vertex_bufferId);
	glBufferData(GL_ARRAY_BUFFER,  sizeof(circle_vertices[0]) * circle_vertices.size(), 
		&circle_vertices.front(), GL_STATIC_DRAW);

	//glVertexAttribPointer(in_Position_loc, 2, GL_FLOAT, GL_FALSE, sizeof(circle_vertices[0]), BUFFER_OFFSET(0));


	// wire square geometry
	// - - - - - - - - - - - -

	square_vertices.push_back(vec2(-0.5, -0.5));
	square_vertices.push_back(vec2(0.5, -0.5));
	square_vertices.push_back(vec2(0.5, 0.5));
	square_vertices.push_back(vec2(-0.5, 0.5));

	// Create vertex buffer
	glGenBuffers(1, &square_vertex_bufferId);
	glBindBuffer(GL_ARRAY_BUFFER, square_vertex_bufferId);
	glBufferData(GL_ARRAY_BUFFER,  sizeof(square_vertices[0]) * square_vertices.size(), 
		&square_vertices.front(), GL_STATIC_DRAW);

	//glVertexAttribPointer(in_Position_loc, 2, GL_FLOAT, GL_FALSE, sizeof(square_vertices[0]), BUFFER_OFFSET(0));

	Mesh::in_position_loc = in_Position_loc;
	grid.init();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// draw 1 unit square centred at 0,0
void square(const mat4& M)
{
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, M);
	glBindBuffer(GL_ARRAY_BUFFER, square_vertex_bufferId);
	glVertexAttribPointer(in_Position_loc, 2, GL_FLOAT, GL_FALSE, sizeof(square_vertices[0]), BUFFER_OFFSET(0));
	glDrawArrays(GL_LINE_LOOP, 0, square_vertices.size());
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void circle(const mat4& M)
{
	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, M);
	glBindBuffer(GL_ARRAY_BUFFER, circle_vertex_bufferId);
	glVertexAttribPointer(in_Position_loc, 2, GL_FLOAT, GL_FALSE, sizeof(circle_vertices[0]), BUFFER_OFFSET(0));
	glDrawArrays(GL_LINE_LOOP, 1, circle_vertices.size() - 2);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

mat4 Translate(float x, float y)
{
	return Translate(x,y,0);
}

mat4 Scale(float x, float y)
{
	return Scale(x,y,1.0);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

bool filledShapes = false;

// different drawShape orders
int drawOrder = 1;

float L = 2.0;
float angle = 10;

// display callback
void display( void )
{
	 // clear the window
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	mat4 P = Ortho2D(0,10,0,10);

	mat4 V = LookAt(vec4(0,10,20,1), vec4(10,0,0,1), vec4(0,1,0,0));
	


	glUniformMatrix4fv(uniformId_modelView, 1, GL_TRUE, P);
	glUniform4fv(uniformId_colour, 1, vec4(0.4f, 0.4f, 0.4f, 0.4f));
	// drawShape the grid
	grid.draw();

	// switch to the square buffer and drawShape it
	glUniform4fv(uniformId_colour, 1, vec4(1.0f, 1.0f, 1.0f, 1.0f));  


	// bottom of jack

	vec4 v(L, 0, 0, 0);

	vec4 va = RotateZ(angle) * v;

	mat4 M = P * Translate(5, 5, 0);

	// left jack
	square(M * Translate(-va.x/2.0, 0, 0) * RotateZ(angle) * Scale(L, 0.2, 1.0) * Translate(0.5, 0, 0));

	// right jack
	square(M * Translate(va.x/2.0, 0, 0) * RotateZ(-angle) * Scale(L, 0.2, 1.0) * Translate(-0.5, 0, 0));
	
	// platform
	square(M * Translate(0, va.y, 0) * Scale(L, 0.2, 1.0));


	//circle(P * Translate(2,2) * Scale(3,2));
	
	// clear the transform with the identity matrix



	//CHECK_GL_ERROR;

	// swap buffers and display
	glutSwapBuffers();
}

#endif

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

void reshape(int width, int height)
{
	std::cout << "reshape " << width << " by " << height << std::endl;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// keyboard event callback function
bool fillAsLines = false;
int lineWidth = 1;
void keyboard( unsigned char key, int x, int y )
{
	switch ( key )
	{
		// Esc key
		case 033:
			exit( EXIT_SUCCESS );
			break;

		case ' ':
			fillAsLines = ! fillAsLines;
			if (fillAsLines)
				glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
			else
				glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
			break;

		case '_':
			// thicken the lines 
			if (++lineWidth > 3) lineWidth = 1;
			glLineWidth(lineWidth);
			break;

		case 'a':
			angle -= 1;
			break;
		case 'A':
			angle += 1;
			break;
		case 'l':
			L -= 0.1;
			break;
		case 'L':
			L += 0.1;
			break;

	}

	std::cout << angle << " " << L << std::endl;


	glutPostRedisplay();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// non ASCII keyboard event callback
void specialKeyboard(int key, int x, int y)
{
		// redraw because something changed
		glutPostRedisplay();

}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

// application entry point
int	main( int argc, char **argv )
{
	// initialize glut
	glutInit( &argc, argv );
	glutInitDisplayMode( GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA );
	glutInitWindowSize( 512, 512 );

	#ifndef __APPLE__
	// If you are using freeglut extensions, ask for an OpenGL
	// version context
    glutInitContextVersion( 2, 1 );
	// this seems to force the most recent version, but would be nice
	// to call since it forces modern OpenGL calls
	//glutInitContextFlags (GLUT_FORWARD_COMPATIBLE );
    //glutInitContextProfile( GLUT_CORE_PROFILE );
	#endif
	// create the window
	glutCreateWindow( "Demo" );

	#ifndef __APPLE__
	// initialize the OpenGL extension wrangler
	glewExperimental = GL_TRUE; // seems to help with older contexts
	GLenum err = glewInit();
	if (GLEW_OK != err)
	{
		std::cerr << "GLEW Error: " << glewGetErrorString(err) << std::endl;
		return 1;
	}
	#endif

	// query for version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	// set window background colour
	glClearColor( 0.0, 0.0, 0.0, 1.0 );

	// enable depth testing


	// blending and smoothing
	glEnable(GL_BLEND); 
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
	glHint( GL_LINE_SMOOTH_HINT, GL_NICEST );
	glHint( GL_POLYGON_SMOOTH_HINT, GL_NICEST );

	// load shaders into the GPU
	initShaders();

	// create geometry and put it into the GPU
	initGeometry();

	// set event callback functions
	glutDisplayFunc( display );
	glutReshapeFunc( reshape );
	glutKeyboardFunc( keyboard );
	glutSpecialFunc( specialKeyboard );


	std::cout << "initializing done" << std::endl;

	// enter the main loop
	glutMainLoop();

	// should never get to this point
	return 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -