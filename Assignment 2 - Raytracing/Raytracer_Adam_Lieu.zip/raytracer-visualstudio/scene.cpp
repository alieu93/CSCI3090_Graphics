//
//  Framework for a raytracer
//  File: scene.cpp
//
//  Created for the Computer Science course "Introduction Computer Graphics"
//  taught at the University of Groningen by Tobias Isenberg.
//
//  Authors:
//    Maarten Everts
//    Jasper van de Gronde
//
//  This framework is inspired by and uses code of the raytracer framework of 
//  Bert Freudenberg that can be found at
//  http://isgwww.cs.uni-magdeburg.de/graphik/lehre/cg2/projekt/rtprojekt.html 
//

#include "scene.h"
#include "material.h"
#include <algorithm>

bool shadows = false;

Color Scene::trace(const Ray &ray)
{
	

	// Might be useful for shadows parts, borrow for shadow part

    // Find hit object and distance
    Hit min_hit(std::numeric_limits<double>::infinity(),Vector());
    Object *obj = NULL;
    for (unsigned int i = 0; i < objects.size(); ++i) {
        Hit hit(objects[i]->intersect(ray));
        if (hit.t<min_hit.t) {
            min_hit = hit;
            obj = objects[i];
        }
    }
	
    // No hit? Return background color.
    if (!obj) return Color(0.0, 0.0, 0.0);

    Material *material = obj->material;            //the hit objects material
    Point hit = ray.at(min_hit.t);                 //the hit point
    Vector N = min_hit.N;                          //the normal at hit point
    Vector V = -ray.D;                             //the view vector

    /****************************************************
    * This is where you should insert the color
    * calculation (Phong model).
    *
    * Given: material, hit, N, V, lights[]
    * Sought: color
    *
    * Hints: (see triple.h)
    *        Triple.dot(Vector) dot product
    *        Vector+Vector      vector sum
    *        Vector-Vector      vector difference
    *        Point-Point        yields vector
    *        Vector.normalize() normalizes vector, returns length
    *        double*Color        scales each color component (r,g,b)
    *        Color*Color        dito
    *        pow(a,b)           a to the power of b
    ****************************************************/

	//Formula: I = k_a * c_r * c_a + sum(k_d * c_r * c_light * max(0, L dot N) + k_a * c_p * c_li * max(0, R dot V)^e)

    //Color color = material->color;                  // place holder

	//Color color = material->color * material->ka // Ambient lighting


	Color color(0.0, 0.0, 0.0);

	Color diffuse, specular;
	
	//Reflection ray
	Triple test = hit + material->reflect * N;
	Ray testRay = Ray(test, ray.D - 2 * (ray.D.dot(N)*N)); //Equation: r = d - 2*(d dot N)*N


	//Refraction
	//eta is the index of refraction of the material
	//ray.D, N
	//From lecture 14 - Ray tracing 2
	//Snell's law: n*sin(theta) = n_t*sin(theta_line) ----> n and n_t can both be eta(?)
	//			This calculates the angle
	// t = (
	double n_squig = 1.0;
	double n_squig_t = material->eta;
	double eta = n_squig / n_squig_t;
	double sqrt_term = 1 - eta*eta * (1 - ray.D.dot(N)*ray.D.dot(N));

	Triple test2 = hit + material->refract*N;


	
	for (int i = 0; i < lights.size(); i++){
		Vector l = (lights[i]->position - hit).normalized();





		//Reflection Direction:
		//Origin: the intersection of the incident ray and the object (point p)
		//Direction: reflected direction is a function of the original ray d and the surface normal :
		//r = d - 2(d dot n)n

		//Vector R((ray.D.x - 2 * (ray.D.dot(N)*N.x)), (ray.D.y - 2 * (ray.D.dot(N)*N.y)), (ray.D.z - 2 * (ray.D.dot(N)*N.z)));




		//Vector r = -l + 2 * (max(l.dot(N), 0.0)) * N; // Formula R = -L + 2(L dot N)N

		//color += material->color * material->ka; // Ambient lighting;

		//If ray intersects another object before it reaches light source, don't do the following lighting
		//Point p...
		//Origin: the intersection of the incident ray and the object (point P)
		//Direction: Subtract p from position of the light source and normalize

		// Just borrowing the eariler part of the code and using it for shadows
		Object *s_obj = NULL;
		Hit s_hit(std::numeric_limits<double>::infinity(), Vector());
		Ray reflected_ray = Ray(hit, l);

		// Yields grainy image though
		// Jiggle needed?

		//add reflected ray
		//Vector Ref = /* YOUR calculation for reflection direction here */
		//	Ref.normalize();
		//Ray reflected_ray = Ray(hit, -Ref);
		//jiggle the hit point to make sure it is outside of the sphere
		//Point hit_jiggle = reflected_ray.at(pow(2, -32));
		// reset the reflected ray to start at the jiggled origin
		//reflected_ray = Ray(hit_jiggle, -Ref);
		// continue with reflection intersections etc.

		Point hit_jiggle = reflected_ray.at(pow(2.0, -32.0)); 
		reflected_ray = Ray(hit_jiggle, l);


		for (int j = 0; j < objects.size(); j++){
			Hit intersect = objects[j]->intersect(reflected_ray);
			if (intersect.t < s_hit.t){
				s_hit = intersect;
				s_obj = objects[j];
			}
		}
		
		if (!s_obj){
			shadows = false;
		}
		else {
			shadows = true;
		}

		if (shadows == true){
			color += material->color * material->ka; //Ambient lighting
		}
		else {

			//Vector l = (lights[i]->position - hit).normalized();
			Vector r = -l + 2 * (max(l.dot(N), 0.0)) * N;

			color += material->color * material->ka; //Ambient lighting
			diffuse = material->kd * material->color * lights[i]->color * max(0.0, l.dot(N)); //Diffuse lighting

				specular = (material->ks * lights[i]->color* pow(max(0.0, V.dot(r)), material->n)); //Specular lighting
				color += diffuse + specular;
			

		}

	}

	//Recursion for reflection
	//Depends on specular lighting
	if (material->ks == 0){
		return color;
	}
	else {
		return color + trace(testRay);
	}

	//Recursion for refraction

	/*
	if (material->refract > 0){
		if (sqrt_term >= 0){
			Vector direction = ((-eta * ray.D.dot(N) - sqrt(sqrt_term)) * N + eta * ray.D);
			Ray refractRay = Ray(test2, direction);
			return color + trace(refractRay);
		}
		else {
			return color;
		}
	}*/

	
	return color;


}

void Scene::render(Image &img)
{
    int w = img.width();
    int h = img.height();
    for (int y = 0; y < h; y++) {
        for (int x = 0; x < w; x++) {
            Point pixel(x, h-1-y, 0);
            Ray ray(eye, (pixel-eye).normalized());
            Color col = trace(ray);
            col.clamp();
            img(x,y) = col;
        }
    }
}

void Scene::addObject(Object *o)
{
    objects.push_back(o);
}

void Scene::addLight(Light *l)
{
    lights.push_back(l);
}

void Scene::setEye(Triple e)
{
    eye = e;
}
