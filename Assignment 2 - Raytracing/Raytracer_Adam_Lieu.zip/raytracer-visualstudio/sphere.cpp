//
//  Framework for a raytracer
//  File: sphere.cpp
//
//  Created for the Computer Science course "Introduction Computer Graphics"
//  taught at the University of Groningen by Tobias Isenberg.
//
//  Authors:
//    Maarten Everts
//    Jasper van de Gronde
//
//  This framework is inspired by and uses code of the raytracer framework of 
//  Bert Freudenberg that can be found at
//  http://isgwww.cs.uni-magdeburg.de/graphik/lehre/cg2/projekt/rtprojekt.html 
//

#include "sphere.h"
#include <iostream>
#include <math.h>
#include <algorithm>

/************************** Sphere **********************************/

Hit Sphere::intersect(const Ray &ray)
{
    /****************************************************
    * RT1.1: INTERSECTION CALCULATION
    *
    * Given: ray, position, r
    * Sought: intersects? if true: *t
    * 
    * Insert calculation of ray/sphere intersection here. 
    *
    * You have the sphere's center (C) and radius (r) as well as
    * the ray's origin (ray.O) and direction (ray.D).
    *
    * If the ray does not intersect the sphere, return false.
    * Otherwise, return true and place the distance of the
    * intersection point from the ray origin in *t (see example).
    ****************************************************/

    // place holder for actual intersection calculation


	/*
    Vector OC = (position - ray.O).normalized();
    if (OC.dot(ray.D) < 0.999) {
        return Hit::NO_HIT();
    }*/

	Vector OC = (position - ray.O);

	double t;

	// Formula for a (d dot d)
	double a = ray.D.dot(ray.D); 
	
	// Formula for b (2(d dot (e - c)))		e = ray's origin (ray.O)    C(sphere center) = position(?)
	double b = 2 * ray.D.dot(ray.O - position);

	// Formula for C ((e-c) dot (e-c) - R^2)
	double c = (ray.O - position).dot(ray.O - position) - (r*r);

	double discriminate = (pow(b, 2) - 4 * a*c);

	if (discriminate < 0){
		return Hit::NO_HIT();
	}

	//Need to calculate roots somehow
	//Quadratic formula: -b (+ or -) sqrt(b^2 -4ac) / 2a

	double r_plus = ((-b) + sqrt(pow(b,2) - 4*a*c)) / (2 * a);

	double r_minus = ((-b) - sqrt(pow(b, 2) - 4 * a*c)) / (2 * a);

	if ((r_plus < 0.0) && (r_minus < 0.0)){
		return Hit::NO_HIT();
	}

	t = find_t(r_plus, r_minus);
	//t = min(r_plus, r_minus);


    /****************************************************
    * RT1.2: NORMAL CALCULATION
    *
    * Given: t, C, r
    * Sought: N
    * 
    * Insert calculation of the sphere's normal at the intersection point.
    ****************************************************/

   // Vector N /* = ... */;

	//Vector N = ((ray.O + ray.D * t) - position) / r;
	//(ray.O - position).x = ray.O.x + t*ray.D.x;

	OC.x = ray.O.x + t*ray.D.x;
	OC.y = ray.O.y + t*ray.D.y;
	OC.z = ray.O.z + t*ray.D.z;


	Vector N = OC - position;
	N.normalize();

    return Hit(t,N);
}

double Sphere::find_t(double r_plus, double r_minus){
	if ((r_plus < 0.0) && (r_minus > 0.0)){
		return r_minus;
	}
	else if ((r_plus > 0.0) && (r_minus < 0.0)){
		return r_plus;
	} else if (r_plus < r_minus){
		return r_plus;
	}else{
		return r_minus;
	}
}